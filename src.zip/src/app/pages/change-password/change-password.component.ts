import { Component } from '@angular/core';
import { HollowButtonComponent } from "../../components/hollow-button/hollow-button.component";
import { ButtonComponent } from "../../components/button/button.component";

@Component({
    selector: 'app-change-password',
    standalone: true,
    templateUrl: './change-password.component.html',
    styleUrl: './change-password.component.scss',
    imports: [HollowButtonComponent, ButtonComponent]
})
export class ChangePasswordComponent {

}
